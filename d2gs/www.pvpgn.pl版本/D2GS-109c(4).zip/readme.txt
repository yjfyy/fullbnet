installation in Windows NT/2k

1. copy the files in this package to a diretory;
2. copy all the Diablo II 1.09c files(DLLs and MPQs) to the same directory;
3. double click the file "install.bat" to install the D2GS server
4. use "regedit" tool to edit some parameters in the system registry,
   in \\HKEY_LOCAL_MACHINE\Software\D2Server\D2GS\, mainly change the "D2CSIP"
   and "D2DBSIP" to your specified IP address, others can remain to default value;
5. start the service "Diablo II Close Game Server" in the system service controler,
   or run "net start d2gs" command.

now you can telnet to the game server's port 8888 to do some administration job.
the default password is "abcd123", and you can changed in the administration console.

enjoy yourself!