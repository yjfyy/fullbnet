Copy these directories to pvpgn-1.8.2\src directory,
then open d2cs_VIP_project\d2cs_VIP\d2cs_VIP.sln with MSVC 2008,
compile.
