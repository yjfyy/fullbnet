/*
 * Copyright (C) 2007,2007	marsgod	(marsgod@263.sina.com)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include "common/setup_before.h"
#include "setup.h"

#include <ctype.h>
#ifdef HAVE_STRING_H
# include <string.h>
#else
# ifdef HAVE_STRINGS_H
#  include <strings.h>
# endif
# ifdef HAVE_MEMORY_H
#  include <memory.h>
# endif
#endif
#ifdef STDC_HEADERS
# include <stdlib.h>
#else
# ifdef HAVE_MALLOC_H
#  include <malloc.h>
# endif
#endif
#include "compat/memcpy.h"
#ifdef HAVE_UNISTD_H
# include <unistd.h>
#endif
#ifdef HAVE_SYS_TYPES_H
# include <sys/types.h>
#endif
#ifdef TIME_WITH_SYS_TIME
# include <time.h>
# include <sys/time.h>
#else
# ifdef HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif
#ifdef HAVE_ASSERT_H
# include <assert.h>
#endif

#include "compat/strcasecmp.h"
#include "prefs.h"
#include "common/eventlog.h"
#include "common/setup_after.h"
#include <stdio.h>
#include <stdlib.h>

#define MAX_ACC_NUM 1000
char ACCLIST[MAX_ACC_NUM][MAX_ACCTNAME_LEN];
time_t ACCTIME[MAX_ACC_NUM];
int total_VIP_accounts;


int VIP_list_init()
{
	int i;
	char *buffer;
	char *pt,*pt2,*pt3;
	FILE *fp;
	struct tm t;
	time_t the_time;
	
	total_VIP_accounts = 0;
	
	memset(ACCLIST,0,sizeof(MAX_ACC_NUM*MAX_ACCTNAME_LEN));
	eventlog(eventlog_level_info,__FUNCTION__,"Trying to open VIP list file %s",prefs_get_VIP_list_file());
	fp = fopen(prefs_get_VIP_list_file(),"r");
	if (fp==NULL)
	{
		eventlog(eventlog_level_error,__FUNCTION__,"error open VIP list file %s",prefs_get_VIP_list_file());
		return -1;
	}
	
	i = 0;

	while(buffer=file_get_line(fp))
	{
		pt=str_skip_space(buffer);
		if (pt[0]=='#') continue;
		
		pt2 = strchr(pt,' ');
		if (pt2 == NULL) pt2 = strchr(pt,'\t');
		if (pt2 == NULL) continue;
		
		while(1)
		{
			if (*pt2 == ' ' || *pt2 == '\t')
			{
				*pt2 = 0;
				pt2 ++;
			}
			else
			if (*pt2 == 0 || *pt2 == '\n' || *pt2 == '\r')
			{
				*pt2 = 0;
				break;
			}
			else
				break;
		}
		
		if (*pt2 == 0) continue;
		
		if (sscanf(pt2,"%04d-%02d-%02d",&t.tm_year,&t.tm_mon,&t.tm_mday) != 3) continue;
		
		t.tm_year -= 1900;
		t.tm_mon --;
		t.tm_hour=0;
		t.tm_min=0;
		t.tm_sec=1;
		t.tm_isdst=0;

		
		the_time = mktime(&t);
		strncpy(ACCLIST[i],pt,MAX_ACCTNAME_LEN);
		ACCTIME[i] = the_time;
//		eventlog(eventlog_level_error,__FUNCTION__,"VIP=(%s)",ACCLIST[i]);
		i++;
		if (i>MAX_ACC_NUM)
		{
			eventlog(eventlog_level_error,__FUNCTION__,"VIP contain too many accounts!(MAX Account=%d)",MAX_ACC_NUM);
			break;
		}
	};
	
	total_VIP_accounts = i;
	eventlog(eventlog_level_info,__FUNCTION__,"Total %d VIP accounts loaded",total_VIP_accounts);
	fclose(fp);
	return 0;
}

time_t VIP_check_acc(char const *accname)
{
	int i;
	time_t		now;
	now=time(NULL);
	
	for (i=0;i<total_VIP_accounts;i++)
	{
		if (strcmpi(accname,ACCLIST[i]) == 0)
		{
			 if(now < ACCTIME[i]) return ACCTIME[i];
			 return 1;
		}
	}
	
	return 0;
}

