              Readme for Player vs. Player Gaming Network
             ---------------------------------------------
	     		   D2Pack 1.09
			  -------------

    PvPGN is a BNETD mod which aims to provide support for all Blizzard 
clients (thus it supports all BNETD supported clients plus the most recent 
ones). 
    This release only includes d2cs/d2dbs as needed to host a Diablo II 1.09 
closed realm. It only supports d2gs 1.09d. This package NEEDS a "bnetd" server 
configured to work (for example use a "bnetd" from a PvPGN release).

The list of supported clients and their minimum verion required is:
- Diablo 2 v1.09 
- Diablo 2 LOD v1.09 
------------

    The documentation is located in the docs directory. Please read docs/INDEX 
for a list of files and what they contain.
    If you are updating from a previous PvPGN version check the file UPDATE 
first.


-----

We're always looking for good coders (C coders) or 
anyone who can contribute to our project in any way.

Project homepages/distribution sites:
- project home and main distribution site: http://pvpgn.berlios.de
- alternate project home: http://www.pvpgn.org
- alternate distribution site: http://www.pvpgn.de

Support channels:

1. BugTracker (preffered support method):
http://developer.berlios.de/bugs/?group_id=2291

2. Mailing List: pvpgn-users@lists.berlios.de ( to subscribe go here 
https://lists.berlios.de/mailman/listinfo/pvpgn-users )

3. Forums: http://forums.pvpgn.org

4. IRC live support: #pvpgn on irc.pvpgn.org
