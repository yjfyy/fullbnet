
CONGRATULATIONS!!!!

WHY ?? BECAUSE YOU ARE ONE OF THE VERY VERY VERY FEW WHO READ THE README FILE!!

But because the other, huge percentage do NOT, we moved the actual contents 
of this file into IGNOREME file because the chances for most of the people to 
read IGNOREME are at least the chances to read README (more than that, we 
believe they are really much higher).

So now, go read IGNOREME with the actual contents what you would have 
expected here.
